//view-terms-worker.js
self.onmessage = async function (e) {
    var html = await fetch(
        '/' + e.data.language + '/workers/search/view/terms/' + e.data.field,
        {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json'
            },
            redirect: 'follow',
            referrerPolicy: 'no-referrer',
            body: JSON.stringify(e.data.params)
        }).then(response => response.text());

    self.postMessage({ field: e.data.field, html });
}