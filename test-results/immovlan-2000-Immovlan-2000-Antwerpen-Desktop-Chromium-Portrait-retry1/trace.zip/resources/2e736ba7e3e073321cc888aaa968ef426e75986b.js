//view-logged-in-worker.js
self.onmessage = async function (e) {
    var html = await fetch(
        '/' + e.data.language + '/workers/authentication/view/logged-in',
        {
            method: 'GET',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json'
            },
            redirect: 'follow',
            referrerPolicy: 'no-referrer'
        }).then(response => response.text());

    self.postMessage(html);
}