//view-worker.js
self.onmessage = async function (e) {
    var html = await fetch(
        '/' + e.data.language + '/cim/view',
        {
            method: 'GET',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            redirect: 'follow',
            referrerPolicy: 'no-referrer'
        }).then(response => response.text());

    self.postMessage(html);
}